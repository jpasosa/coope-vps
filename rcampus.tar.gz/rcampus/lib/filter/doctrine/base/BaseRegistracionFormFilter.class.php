<?php

/**
 * Registracion filter form base class.
 *
 * @package    rcampus
 * @subpackage filter
 * @author     Your name here
 * @version    SVN: $Id: sfDoctrineFormFilterGeneratedTemplate.php 29570 2010-05-21 14:49:47Z Kris.Wallsmith $
 */
abstract class BaseRegistracionFormFilter extends BaseFormFilterDoctrine
{
  public function setup()
  {
    $this->setWidgets(array(
      'p_apellido'            => new sfWidgetFormFilterInput(array('with_empty' => false)),
      'p_nombre'              => new sfWidgetFormFilterInput(array('with_empty' => false)),
      'p_sexo'                => new sfWidgetFormChoice(array('choices' => array('' => 'yes or no', 1 => 'yes', 0 => 'no'))),
      'p_edad'                => new sfWidgetFormFilterInput(),
      'p_dni'                 => new sfWidgetFormFilterInput(array('with_empty' => false)),
      'p_email'               => new sfWidgetFormFilterInput(),
      'p_provincia'           => new sfWidgetFormFilterInput(),
      'p_ciudad'              => new sfWidgetFormFilterInput(),
      'p_localidad'           => new sfWidgetFormFilterInput(),
      'p_titulo_obtenido'     => new sfWidgetFormFilterInput(),
      'p_acceso_internet'     => new sfWidgetFormChoice(array('choices' => array('' => 'yes or no', 1 => 'yes', 0 => 'no'))),
      'p_realizado_curso'     => new sfWidgetFormChoice(array('choices' => array('' => 'yes or no', 1 => 'yes', 0 => 'no'))),
      't_institucion'         => new sfWidgetFormFilterInput(),
      't_nombre'              => new sfWidgetFormFilterInput(),
      't_domicilio'           => new sfWidgetFormFilterInput(),
      't_localidad'           => new sfWidgetFormFilterInput(),
      't_ciudad'              => new sfWidgetFormFilterInput(),
      't_departamento'        => new sfWidgetFormFilterInput(),
      't_provincia'           => new sfWidgetFormFilterInput(),
      't_dependede'           => new sfWidgetFormFilterInput(),
      't_cargo'               => new sfWidgetFormFilterInput(),
      't_descripcion_tareas'  => new sfWidgetFormFilterInput(),
      'f_cursos_pol_sociales' => new sfWidgetFormChoice(array('choices' => array('' => 'yes or no', 1 => 'yes', 0 => 'no'))),
      'f_cursos_niniez'       => new sfWidgetFormChoice(array('choices' => array('' => 'yes or no', 1 => 'yes', 0 => 'no'))),
      'f_tematicas_curso'     => new sfWidgetFormFilterInput(),
      'f_lugarcurso'          => new sfWidgetFormFilterInput(),
      'f_lugarcurso_otro'     => new sfWidgetFormFilterInput(),
      'aprobado'              => new sfWidgetFormChoice(array('choices' => array('' => 'yes or no', 1 => 'yes', 0 => 'no'))),
      'ingresado'             => new sfWidgetFormChoice(array('choices' => array('' => 'yes or no', 1 => 'yes', 0 => 'no'))),
      'created_at'            => new sfWidgetFormFilterDate(array('from_date' => new sfWidgetFormDate(), 'to_date' => new sfWidgetFormDate(), 'with_empty' => false)),
      'updated_at'            => new sfWidgetFormFilterDate(array('from_date' => new sfWidgetFormDate(), 'to_date' => new sfWidgetFormDate(), 'with_empty' => false)),
    ));

    $this->setValidators(array(
      'p_apellido'            => new sfValidatorPass(array('required' => false)),
      'p_nombre'              => new sfValidatorPass(array('required' => false)),
      'p_sexo'                => new sfValidatorChoice(array('required' => false, 'choices' => array('', 1, 0))),
      'p_edad'                => new sfValidatorPass(array('required' => false)),
      'p_dni'                 => new sfValidatorPass(array('required' => false)),
      'p_email'               => new sfValidatorPass(array('required' => false)),
      'p_provincia'           => new sfValidatorPass(array('required' => false)),
      'p_ciudad'              => new sfValidatorPass(array('required' => false)),
      'p_localidad'           => new sfValidatorPass(array('required' => false)),
      'p_titulo_obtenido'     => new sfValidatorPass(array('required' => false)),
      'p_acceso_internet'     => new sfValidatorChoice(array('required' => false, 'choices' => array('', 1, 0))),
      'p_realizado_curso'     => new sfValidatorChoice(array('required' => false, 'choices' => array('', 1, 0))),
      't_institucion'         => new sfValidatorPass(array('required' => false)),
      't_nombre'              => new sfValidatorPass(array('required' => false)),
      't_domicilio'           => new sfValidatorPass(array('required' => false)),
      't_localidad'           => new sfValidatorPass(array('required' => false)),
      't_ciudad'              => new sfValidatorPass(array('required' => false)),
      't_departamento'        => new sfValidatorPass(array('required' => false)),
      't_provincia'           => new sfValidatorPass(array('required' => false)),
      't_dependede'           => new sfValidatorPass(array('required' => false)),
      't_cargo'               => new sfValidatorPass(array('required' => false)),
      't_descripcion_tareas'  => new sfValidatorPass(array('required' => false)),
      'f_cursos_pol_sociales' => new sfValidatorChoice(array('required' => false, 'choices' => array('', 1, 0))),
      'f_cursos_niniez'       => new sfValidatorChoice(array('required' => false, 'choices' => array('', 1, 0))),
      'f_tematicas_curso'     => new sfValidatorPass(array('required' => false)),
      'f_lugarcurso'          => new sfValidatorPass(array('required' => false)),
      'f_lugarcurso_otro'     => new sfValidatorPass(array('required' => false)),
      'aprobado'              => new sfValidatorChoice(array('required' => false, 'choices' => array('', 1, 0))),
      'ingresado'             => new sfValidatorChoice(array('required' => false, 'choices' => array('', 1, 0))),
      'created_at'            => new sfValidatorDateRange(array('required' => false, 'from_date' => new sfValidatorDateTime(array('required' => false, 'datetime_output' => 'Y-m-d 00:00:00')), 'to_date' => new sfValidatorDateTime(array('required' => false, 'datetime_output' => 'Y-m-d 23:59:59')))),
      'updated_at'            => new sfValidatorDateRange(array('required' => false, 'from_date' => new sfValidatorDateTime(array('required' => false, 'datetime_output' => 'Y-m-d 00:00:00')), 'to_date' => new sfValidatorDateTime(array('required' => false, 'datetime_output' => 'Y-m-d 23:59:59')))),
    ));

    $this->widgetSchema->setNameFormat('registracion_filters[%s]');

    $this->errorSchema = new sfValidatorErrorSchema($this->validatorSchema);

    $this->setupInheritance();

    parent::setup();
  }

  public function getModelName()
  {
    return 'Registracion';
  }

  public function getFields()
  {
    return array(
      'id'                    => 'Number',
      'p_apellido'            => 'Text',
      'p_nombre'              => 'Text',
      'p_sexo'                => 'Boolean',
      'p_edad'                => 'Text',
      'p_dni'                 => 'Text',
      'p_email'               => 'Text',
      'p_provincia'           => 'Text',
      'p_ciudad'              => 'Text',
      'p_localidad'           => 'Text',
      'p_titulo_obtenido'     => 'Text',
      'p_acceso_internet'     => 'Boolean',
      'p_realizado_curso'     => 'Boolean',
      't_institucion'         => 'Text',
      't_nombre'              => 'Text',
      't_domicilio'           => 'Text',
      't_localidad'           => 'Text',
      't_ciudad'              => 'Text',
      't_departamento'        => 'Text',
      't_provincia'           => 'Text',
      't_dependede'           => 'Text',
      't_cargo'               => 'Text',
      't_descripcion_tareas'  => 'Text',
      'f_cursos_pol_sociales' => 'Boolean',
      'f_cursos_niniez'       => 'Boolean',
      'f_tematicas_curso'     => 'Text',
      'f_lugarcurso'          => 'Text',
      'f_lugarcurso_otro'     => 'Text',
      'aprobado'              => 'Boolean',
      'ingresado'             => 'Boolean',
      'created_at'            => 'Date',
      'updated_at'            => 'Date',
    );
  }
}
