<?php

/**
 * Registracion form base class.
 *
 * @method Registracion getObject() Returns the current form's model object
 *
 * @package    rcampus
 * @subpackage form
 * @author     Your name here
 * @version    SVN: $Id: sfDoctrineFormGeneratedTemplate.php 29553 2010-05-20 14:33:00Z Kris.Wallsmith $
 */
abstract class BaseRegistracionForm extends BaseFormDoctrine
{
  public function setup()
  {
    $this->setWidgets(array(
      'id'                    => new sfWidgetFormInputHidden(),
      'p_apellido'            => new sfWidgetFormInputText(),
      'p_nombre'              => new sfWidgetFormInputText(),
      'p_sexo'                => new sfWidgetFormInputCheckbox(),
      'p_edad'                => new sfWidgetFormInputText(),
      'p_dni'                 => new sfWidgetFormInputText(),
      'p_email'               => new sfWidgetFormInputText(),
      'p_provincia'           => new sfWidgetFormInputText(),
      'p_ciudad'              => new sfWidgetFormInputText(),
      'p_localidad'           => new sfWidgetFormInputText(),
      'p_titulo_obtenido'     => new sfWidgetFormInputText(),
      'p_acceso_internet'     => new sfWidgetFormInputCheckbox(),
      'p_realizado_curso'     => new sfWidgetFormInputCheckbox(),
      't_institucion'         => new sfWidgetFormInputText(),
      't_nombre'              => new sfWidgetFormInputText(),
      't_domicilio'           => new sfWidgetFormInputText(),
      't_localidad'           => new sfWidgetFormInputText(),
      't_ciudad'              => new sfWidgetFormInputText(),
      't_departamento'        => new sfWidgetFormInputText(),
      't_provincia'           => new sfWidgetFormInputText(),
      't_dependede'           => new sfWidgetFormInputText(),
      't_cargo'               => new sfWidgetFormInputText(),
      't_descripcion_tareas'  => new sfWidgetFormInputText(),
      'f_cursos_pol_sociales' => new sfWidgetFormInputCheckbox(),
      'f_cursos_niniez'       => new sfWidgetFormInputCheckbox(),
      'f_tematicas_curso'     => new sfWidgetFormInputText(),
      'f_lugarcurso'          => new sfWidgetFormInputText(),
      'f_lugarcurso_otro'     => new sfWidgetFormInputText(),
      'aprobado'              => new sfWidgetFormInputCheckbox(),
      'ingresado'             => new sfWidgetFormInputCheckbox(),
      'created_at'            => new sfWidgetFormDateTime(),
      'updated_at'            => new sfWidgetFormDateTime(),
    ));

    $this->setValidators(array(
      'id'                    => new sfValidatorChoice(array('choices' => array($this->getObject()->get('id')), 'empty_value' => $this->getObject()->get('id'), 'required' => false)),
      'p_apellido'            => new sfValidatorString(array('max_length' => 255)),
      'p_nombre'              => new sfValidatorString(array('max_length' => 255)),
      'p_sexo'                => new sfValidatorBoolean(array('required' => false)),
      'p_edad'                => new sfValidatorPass(array('required' => false)),
      'p_dni'                 => new sfValidatorPass(),
      'p_email'               => new sfValidatorString(array('max_length' => 255, 'required' => false)),
      'p_provincia'           => new sfValidatorString(array('max_length' => 255, 'required' => false)),
      'p_ciudad'              => new sfValidatorString(array('max_length' => 255, 'required' => false)),
      'p_localidad'           => new sfValidatorString(array('max_length' => 255, 'required' => false)),
      'p_titulo_obtenido'     => new sfValidatorString(array('max_length' => 255, 'required' => false)),
      'p_acceso_internet'     => new sfValidatorBoolean(array('required' => false)),
      'p_realizado_curso'     => new sfValidatorBoolean(array('required' => false)),
      't_institucion'         => new sfValidatorString(array('max_length' => 255, 'required' => false)),
      't_nombre'              => new sfValidatorString(array('max_length' => 255, 'required' => false)),
      't_domicilio'           => new sfValidatorString(array('max_length' => 255, 'required' => false)),
      't_localidad'           => new sfValidatorString(array('max_length' => 255, 'required' => false)),
      't_ciudad'              => new sfValidatorString(array('max_length' => 255, 'required' => false)),
      't_departamento'        => new sfValidatorString(array('max_length' => 255, 'required' => false)),
      't_provincia'           => new sfValidatorString(array('max_length' => 255, 'required' => false)),
      't_dependede'           => new sfValidatorString(array('max_length' => 255, 'required' => false)),
      't_cargo'               => new sfValidatorString(array('max_length' => 255, 'required' => false)),
      't_descripcion_tareas'  => new sfValidatorString(array('max_length' => 255, 'required' => false)),
      'f_cursos_pol_sociales' => new sfValidatorBoolean(array('required' => false)),
      'f_cursos_niniez'       => new sfValidatorBoolean(array('required' => false)),
      'f_tematicas_curso'     => new sfValidatorString(array('max_length' => 255, 'required' => false)),
      'f_lugarcurso'          => new sfValidatorString(array('max_length' => 255, 'required' => false)),
      'f_lugarcurso_otro'     => new sfValidatorString(array('max_length' => 255, 'required' => false)),
      'aprobado'              => new sfValidatorBoolean(array('required' => false)),
      'ingresado'             => new sfValidatorBoolean(array('required' => false)),
      'created_at'            => new sfValidatorDateTime(),
      'updated_at'            => new sfValidatorDateTime(),
    ));

    $this->widgetSchema->setNameFormat('registracion[%s]');

    $this->errorSchema = new sfValidatorErrorSchema($this->validatorSchema);

    $this->setupInheritance();

    parent::setup();
  }

  public function getModelName()
  {
    return 'Registracion';
  }

}
