<?php

/**
 * Registracion form.
 *
 * @package    rcampus
 * @subpackage form
 * @author     Your name here
 * @version    SVN: $Id: sfDoctrineFormTemplate.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class RegistracionForm extends BaseRegistracionForm
{
  public function configure()
  {
    unset(
      $this['created_at'], $this['updated_at']
    );

    $this->widgetSchema['f_lugarcurso'] = new sfWidgetFormChoice(array(
      'choices'  => Doctrine_Core::getTable('Registracion')->getLugar_curso(),
      'expanded' => true,
    ));
    $this->widgetSchema['p_sexo'] = new sfWidgetFormChoice(array(
      'choices'  => Doctrine_Core::getTable('Registracion')->getSexo(),
      'expanded' => true,
    ));
    $this->widgetSchema['p_acceso_internet'] = new sfWidgetFormChoice(array(
      'choices'  => Doctrine_Core::getTable('Registracion')->getAcceso_internet(),
      'expanded' => true,
    ));
    $this->widgetSchema['p_realizado_curso'] = new sfWidgetFormChoice(array(
      'choices'  => Doctrine_Core::getTable('Registracion')->getCursos_anteriores(),
      'expanded' => true,
    ));
    $this->widgetSchema['f_cursos_pol_sociales'] = new sfWidgetFormChoice(array(
      'choices'  => Doctrine_Core::getTable('Registracion')->getPoliticas_sociales(),
      'expanded' => true,
    ));
    $this->widgetSchema['f_cursos_niniez'] = new sfWidgetFormChoice(array(
      'choices'  => Doctrine_Core::getTable('Registracion')->getCursos_niniez(),
      'expanded' => true,
    ));
  
  // Agrego validacion de email
  $this->validatorSchema['p_email'] = new sfValidatorAnd(array(
    $this->validatorSchema['p_email'],
    new sfValidatorEmail(),
  ));
  $this->setValidators(array(
    // pongo q no hace falta el id, por que no es un campo q va a entrar el usuario
    'id'                  => new sfValidatorNumber(array( 
                           'required' => false)),
    'p_apellido'          => new sfValidatorString(array(
                            'min_length'  => 3,
                            'max_length'  => 255), array(
                            'required'    => '*campo obligatorio',
                            'min_length'  => '*debes escribir más de 3 carácteres',
                            'max_length'  => 'no puedes exceder los 255 carácteres')),
    'p_nombre'          => new sfValidatorString(array(
                            'min_length'  => 3,
                            'max_length'  => 255), array(
                            'required'    => '*campo obligatorio',
                            'min_length'  => '*debes escribir más de 3 carácteres',
                            'max_length'  => 'no puedes exceder los 255 carácteres')),
    'p_sexo'        => new sfValidatorString(array(), array(
                            'required' => '*campo obligatorio')),
    'p_edad'          => new sfValidatorNumber(array(
                            'min'  => 12,
                            'max'  => 120), array(
                            'required'  => '*campo obligatorio',
                            'invalid'   => '*no se reconoce como una edad lo ingresado',
                            'min'  => '*debes tener al menos 12 años',
                            'max'  => '*no debes exceder la edad de 120 años')),
    'p_dni'               => new sfValidatorNumber(array(
                            'min'  => 1000000,
                            'max'  => 500000000), array(
                            'required'  => '*campo obligatorio',
                            'invalid'   => '*no se reconoce como un DNI',
                            'min'  => '*es un valor chico para un DNI',
                            'max'  => '*es un valor grande para un DNI')),
    'p_email'             => new sfValidatorEmail(array(), array(
                            'required' => '*campo obligatorio',
                            'invalid'  => '* Debes ingresar un email válido')),
    'p_provincia'         => new sfValidatorString(array(), array(
                            'required' => '* campo obligatorio')),
    'p_ciudad'            => new sfValidatorString(array(), array(
                            'required' => '* campo obligatorio')),
    'p_localidad'         => new sfValidatorString(array(), array('required' => 'saranga')),
    'p_titulo_obtenido'   => new sfValidatorString(array(), array(
                            'required' => '* campo obligatorio')),
    'p_acceso_internet'   => new sfValidatorString(array(), array(
                            'required' => '* campo obligatorio')),
    'p_realizado_curso'   => new sfValidatorString(array(), array(
                            'required' => '*campo obligatorio')),
    't_institucion'       => new sfValidatorString(array(), array(
                            'required' => '*campo obligatorio')),
    't_nombre'            => new sfValidatorString(array(), array(
                            'required' => '*campo obligatorio')),
    't_domicilio'         => new sfValidatorString(array(), array(
                            'required' => '*campo obligatorio')),
    't_localidad'         => new sfValidatorString(array(), array(
                            'required' => '*campo obligatorio')),
    't_ciudad'            => new sfValidatorString(array(), array(
                            'required' => '*campo obligatorio')),   
    't_departamento'      => new sfValidatorString(array(), array(
                            'required' => '*campo obligatorio')),
    't_provincia'         => new sfValidatorString(array(), array(
                            'required' => '*campo obligatorio')),
    't_dependede'         => new sfValidatorString(array(), array(
                            'required' => '*campo obligatorio')),
    't_cargo'             => new sfValidatorString(array(), array(
                            'required' => '*campo obligatorio')),
    't_descripcion_tareas'=> new sfValidatorString(array(), array(
                            'required' => '*campo obligatorioo')),
    'f_cursos_pol_sociales'=> new sfValidatorString(array(), array(
                            'required' => '*campo obligatorio')),
    'f_cursos_niniez'     => new sfValidatorString(array(), array(
                            'required' => '*campo obligatorio')),
    'f_tematicas_curso'   => new sfValidatorString(array(), array(
                            'required' => '*campo obligatorio')),
    'f_lugarcurso'        => new sfValidatorString(array(), array(
                            'required' => '*campo obligatorio')),
    'f_lugarcurso_otro'   => new sfValidatorString(array(), array(
                            'required' => '*campo obligatorio'))
));




    $this->widgetSchema->setLabels(array(
      'p_apellido'            => 'Apellido',
      'p_nombre'              => 'Nombre',
      'p_sexo'                => 'Sexo',
      'p_edad'                => 'Edad',
      'p_dni'                 => 'DNI',
      'p_email'               => 'Email',
      'p_provincia'           => 'Provincia',
      'p_ciudad'              => 'Ciudad',
      'p_localidad'           => 'Localidad',
      'p_titulo_obtenido'     => 'Titulo Obtenido',
      'p_acceso_internet'     => '¿Tiene acceso a internet?',
      'p_realizado_curso'     => '¿Ha realizado cursos anteriormente?',
      't_institucion'         => 'Institucion en la que trabaja',
      't_nombre'              => 'Nombre de la Institucion',
      't_domicilio'           => 'Domicilio',
      't_localidad'           => 'Localidad',
      't_ciudad'              => 'Ciudad',
      't_departamento'        => 'Departamento',
      't_provincia'           => 'Provincia',
      't_dependede'           => 'Dependencia',
      't_cargo'               => 'Cargo',
      't_descripcion_tareas'  => 'Descripcion de Tareas',
      'f_cursos_pol_sociales' => 'Cursos sobre Politicas Sociales',
      'f_cursos_niniez'       => 'Cursos sobre Niñez',
      'f_tematicas_curso'     => 'Tematicas del Curso',
      'f_lugarcurso'          => 'Lugar Curso',
      'f_lugarcurso_otro'     => 'Otro Lugar Curso'
    ));



  }
}
