<td>
  <input type="checkbox" name="ids[]" value="<?php echo $registracion->getPrimaryKey() ?>" class="sf_admin_batch_checkbox" />
</td>
