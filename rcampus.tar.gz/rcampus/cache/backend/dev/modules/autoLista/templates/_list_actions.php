<?php if ($sf_user->hasCredential('N')): ?>
<?php echo $helper->linkToNew('None') ?>
<?php endif; ?>

<li class="sf_admin_action_registrantstocsv">
  <?php echo link_to(__('Exportar aprobados a .csv', array(), 'messages'), 'lista/ListRegistrantsToCsv', array()) ?>
</li>
