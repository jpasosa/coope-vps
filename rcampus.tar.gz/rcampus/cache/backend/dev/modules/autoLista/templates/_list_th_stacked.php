<?php include_partial('lista/list_th_tabular', array('sort' => $sort)) ?>
