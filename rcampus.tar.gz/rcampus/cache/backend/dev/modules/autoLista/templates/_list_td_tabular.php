<td class="sf_admin_text sf_admin_list_td_p_nombre">
  <?php echo $registracion->getPNombre() ?>
</td>
<td class="sf_admin_text sf_admin_list_td_p_apellido">
  <?php echo $registracion->getPApellido() ?>
</td>
<td class="sf_admin_text sf_admin_list_td_p_edad">
  <?php echo $registracion->getPEdad() ?>
</td>
<td class="sf_admin_text sf_admin_list_td_t_institucion">
  <?php echo $registracion->getTInstitucion() ?>
</td>
<td class="sf_admin_text sf_admin_list_td_t_cargo">
  <?php echo $registracion->getTCargo() ?>
</td>
<td class="sf_admin_text sf_admin_list_td_p_titulo_obtenido">
  <?php echo $registracion->getPTituloObtenido() ?>
</td>
<td class="sf_admin_boolean sf_admin_list_td_p_acceso_internet">
  <?php echo get_partial('lista/list_field_boolean', array('value' => $registracion->getPAccesoInternet())) ?>
</td>
<td class="sf_admin_text sf_admin_list_td_t_dependede">
  <?php echo $registracion->getTDependede() ?>
</td>
<td class="sf_admin_boolean sf_admin_list_td_aprobado">
  <?php echo get_partial('lista/list_field_boolean', array('value' => $registracion->getAprobado())) ?>
</td>
