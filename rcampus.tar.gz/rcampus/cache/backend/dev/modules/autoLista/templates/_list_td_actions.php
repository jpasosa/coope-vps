<td>
  <ul class="sf_admin_td_actions">
    <li class="sf_admin_action_ver">
      <?php echo link_to(__('Ver', array(), 'messages'), 'lista/ListVer?id='.$registracion->getId(), array()) ?>
    </li>
    <?php echo $helper->linkToDelete($registracion, array(  'params' =>   array(  ),  'confirm' => 'Are you sure?',  'class_suffix' => 'delete',  'label' => 'Delete',)) ?>
  </ul>
</td>
