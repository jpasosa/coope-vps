<?php

/**
 * lista module configuration.
 *
 * @package    ##PROJECT_NAME##
 * @subpackage lista
 * @author     ##AUTHOR_NAME##
 * @version    SVN: $Id: configuration.php 24171 2009-11-19 16:37:50Z Kris.Wallsmith $
 */
abstract class BaseListaGeneratorConfiguration extends sfModelGeneratorConfiguration
{
  public function getActionsDefault()
  {
    return array();
  }

  public function getFormActions()
  {
    return array(  '_delete' => NULL,  '_list' => NULL,  '_save' => NULL,  '_save_and_add' => NULL,);
  }

  public function getNewActions()
  {
    return array();
  }

  public function getEditActions()
  {
    return array();
  }

  public function getListObjectActions()
  {
    return array(  'Ver' => NULL,  '_delete' => NULL,);
  }

  public function getListActions()
  {
    return array(  '_new' => 'none',  'RegistrantsToCsv' =>   array(    'label' => 'Exportar aprobados a .csv',  ),);
  }

  public function getListBatchActions()
  {
    return array(  'Aprobar' => NULL,  'Desaprobar' => NULL,);
  }

  public function getListParams()
  {
    return '%%p_nombre%% - %%p_apellido%% - %%p_edad%% - %%t_institucion%% - %%t_cargo%% - %%p_titulo_obtenido%% - %%p_acceso_internet%% - %%t_institucion%% - %%t_dependede%% - %%t_cargo%% - %%aprobado%%';
  }

  public function getListLayout()
  {
    return 'tabular';
  }

  public function getListTitle()
  {
    return 'Lista List';
  }

  public function getEditTitle()
  {
    return 'Edit Lista';
  }

  public function getNewTitle()
  {
    return 'New Lista';
  }

  public function getFilterDisplay()
  {
    return array();
  }

  public function getFormDisplay()
  {
    return array();
  }

  public function getEditDisplay()
  {
    return array();
  }

  public function getNewDisplay()
  {
    return array();
  }

  public function getListDisplay()
  {
    return array(  0 => 'p_nombre',  1 => 'p_apellido',  2 => 'p_edad',  3 => 't_institucion',  4 => 't_cargo',  5 => 'p_titulo_obtenido',  6 => 'p_acceso_internet',  7 => 't_institucion',  8 => 't_dependede',  9 => 't_cargo',  10 => 'aprobado',);
  }

  public function getFieldsDefault()
  {
    return array(
      'id' => array(  'is_link' => true,  'is_real' => true,  'is_partial' => false,  'is_component' => false,  'type' => 'Text',),
      'p_apellido' => array(  'is_link' => false,  'is_real' => true,  'is_partial' => false,  'is_component' => false,  'type' => 'Text',  'label' => 'Apellido',),
      'p_nombre' => array(  'is_link' => false,  'is_real' => true,  'is_partial' => false,  'is_component' => false,  'type' => 'Text',  'label' => 'Nombre',  'help' => 'Este es el nombre',),
      'p_sexo' => array(  'is_link' => false,  'is_real' => true,  'is_partial' => false,  'is_component' => false,  'type' => 'Boolean',),
      'p_edad' => array(  'is_link' => false,  'is_real' => true,  'is_partial' => false,  'is_component' => false,  'type' => 'Text',  'label' => 'Edad',),
      'p_dni' => array(  'is_link' => false,  'is_real' => true,  'is_partial' => false,  'is_component' => false,  'type' => 'Text',),
      'p_email' => array(  'is_link' => false,  'is_real' => true,  'is_partial' => false,  'is_component' => false,  'type' => 'Text',),
      'p_provincia' => array(  'is_link' => false,  'is_real' => true,  'is_partial' => false,  'is_component' => false,  'type' => 'Text',),
      'p_ciudad' => array(  'is_link' => false,  'is_real' => true,  'is_partial' => false,  'is_component' => false,  'type' => 'Text',),
      'p_localidad' => array(  'is_link' => false,  'is_real' => true,  'is_partial' => false,  'is_component' => false,  'type' => 'Text',),
      'p_titulo_obtenido' => array(  'is_link' => false,  'is_real' => true,  'is_partial' => false,  'is_component' => false,  'type' => 'Text',  'label' => 'Título',),
      'p_acceso_internet' => array(  'is_link' => false,  'is_real' => true,  'is_partial' => false,  'is_component' => false,  'type' => 'Boolean',  'label' => 'Internet',),
      'p_realizado_curso' => array(  'is_link' => false,  'is_real' => true,  'is_partial' => false,  'is_component' => false,  'type' => 'Boolean',),
      't_institucion' => array(  'is_link' => false,  'is_real' => true,  'is_partial' => false,  'is_component' => false,  'type' => 'Text',  'label' => 'Institucion',  'help' => 'En donde trabaja',),
      't_nombre' => array(  'is_link' => false,  'is_real' => true,  'is_partial' => false,  'is_component' => false,  'type' => 'Text',),
      't_domicilio' => array(  'is_link' => false,  'is_real' => true,  'is_partial' => false,  'is_component' => false,  'type' => 'Text',),
      't_localidad' => array(  'is_link' => false,  'is_real' => true,  'is_partial' => false,  'is_component' => false,  'type' => 'Text',),
      't_ciudad' => array(  'is_link' => false,  'is_real' => true,  'is_partial' => false,  'is_component' => false,  'type' => 'Text',),
      't_departamento' => array(  'is_link' => false,  'is_real' => true,  'is_partial' => false,  'is_component' => false,  'type' => 'Text',),
      't_provincia' => array(  'is_link' => false,  'is_real' => true,  'is_partial' => false,  'is_component' => false,  'type' => 'Text',),
      't_dependede' => array(  'is_link' => false,  'is_real' => true,  'is_partial' => false,  'is_component' => false,  'type' => 'Text',  'label' => 'Depndencia',),
      't_cargo' => array(  'is_link' => false,  'is_real' => true,  'is_partial' => false,  'is_component' => false,  'type' => 'Text',  'label' => 'Cargo',),
      't_descripcion_tareas' => array(  'is_link' => false,  'is_real' => true,  'is_partial' => false,  'is_component' => false,  'type' => 'Text',),
      'f_cursos_pol_sociales' => array(  'is_link' => false,  'is_real' => true,  'is_partial' => false,  'is_component' => false,  'type' => 'Boolean',),
      'f_cursos_niniez' => array(  'is_link' => false,  'is_real' => true,  'is_partial' => false,  'is_component' => false,  'type' => 'Boolean',),
      'f_tematicas_curso' => array(  'is_link' => false,  'is_real' => true,  'is_partial' => false,  'is_component' => false,  'type' => 'Text',),
      'f_lugarcurso' => array(  'is_link' => false,  'is_real' => true,  'is_partial' => false,  'is_component' => false,  'type' => 'Text',),
      'f_lugarcurso_otro' => array(  'is_link' => false,  'is_real' => true,  'is_partial' => false,  'is_component' => false,  'type' => 'Text',),
      'aprobado' => array(  'is_link' => false,  'is_real' => true,  'is_partial' => false,  'is_component' => false,  'type' => 'Boolean',),
      'ingresado' => array(  'is_link' => false,  'is_real' => true,  'is_partial' => false,  'is_component' => false,  'type' => 'Boolean',),
      'created_at' => array(  'is_link' => false,  'is_real' => true,  'is_partial' => false,  'is_component' => false,  'type' => 'Date',),
      'updated_at' => array(  'is_link' => false,  'is_real' => true,  'is_partial' => false,  'is_component' => false,  'type' => 'Date',),
    );
  }

  public function getFieldsList()
  {
    return array(
      'id' => array(),
      'p_apellido' => array(),
      'p_nombre' => array(),
      'p_sexo' => array(),
      'p_edad' => array(),
      'p_dni' => array(),
      'p_email' => array(),
      'p_provincia' => array(),
      'p_ciudad' => array(),
      'p_localidad' => array(),
      'p_titulo_obtenido' => array(),
      'p_acceso_internet' => array(),
      'p_realizado_curso' => array(),
      't_institucion' => array(),
      't_nombre' => array(),
      't_domicilio' => array(),
      't_localidad' => array(),
      't_ciudad' => array(),
      't_departamento' => array(),
      't_provincia' => array(),
      't_dependede' => array(),
      't_cargo' => array(),
      't_descripcion_tareas' => array(),
      'f_cursos_pol_sociales' => array(),
      'f_cursos_niniez' => array(),
      'f_tematicas_curso' => array(),
      'f_lugarcurso' => array(),
      'f_lugarcurso_otro' => array(),
      'aprobado' => array(),
      'ingresado' => array(),
      'created_at' => array(),
      'updated_at' => array(),
    );
  }

  public function getFieldsFilter()
  {
    return array(
      'id' => array(),
      'p_apellido' => array(),
      'p_nombre' => array(),
      'p_sexo' => array(),
      'p_edad' => array(),
      'p_dni' => array(),
      'p_email' => array(),
      'p_provincia' => array(),
      'p_ciudad' => array(),
      'p_localidad' => array(),
      'p_titulo_obtenido' => array(),
      'p_acceso_internet' => array(),
      'p_realizado_curso' => array(),
      't_institucion' => array(),
      't_nombre' => array(),
      't_domicilio' => array(),
      't_localidad' => array(),
      't_ciudad' => array(),
      't_departamento' => array(),
      't_provincia' => array(),
      't_dependede' => array(),
      't_cargo' => array(),
      't_descripcion_tareas' => array(),
      'f_cursos_pol_sociales' => array(),
      'f_cursos_niniez' => array(),
      'f_tematicas_curso' => array(),
      'f_lugarcurso' => array(),
      'f_lugarcurso_otro' => array(),
      'aprobado' => array(),
      'ingresado' => array(),
      'created_at' => array(),
      'updated_at' => array(),
    );
  }

  public function getFieldsForm()
  {
    return array(
      'id' => array(),
      'p_apellido' => array(),
      'p_nombre' => array(),
      'p_sexo' => array(),
      'p_edad' => array(),
      'p_dni' => array(),
      'p_email' => array(),
      'p_provincia' => array(),
      'p_ciudad' => array(),
      'p_localidad' => array(),
      'p_titulo_obtenido' => array(),
      'p_acceso_internet' => array(),
      'p_realizado_curso' => array(),
      't_institucion' => array(),
      't_nombre' => array(),
      't_domicilio' => array(),
      't_localidad' => array(),
      't_ciudad' => array(),
      't_departamento' => array(),
      't_provincia' => array(),
      't_dependede' => array(),
      't_cargo' => array(),
      't_descripcion_tareas' => array(),
      'f_cursos_pol_sociales' => array(),
      'f_cursos_niniez' => array(),
      'f_tematicas_curso' => array(),
      'f_lugarcurso' => array(),
      'f_lugarcurso_otro' => array(),
      'aprobado' => array(),
      'ingresado' => array(),
      'created_at' => array(),
      'updated_at' => array(),
    );
  }

  public function getFieldsEdit()
  {
    return array(
      'id' => array(),
      'p_apellido' => array(),
      'p_nombre' => array(),
      'p_sexo' => array(),
      'p_edad' => array(),
      'p_dni' => array(),
      'p_email' => array(),
      'p_provincia' => array(),
      'p_ciudad' => array(),
      'p_localidad' => array(),
      'p_titulo_obtenido' => array(),
      'p_acceso_internet' => array(),
      'p_realizado_curso' => array(),
      't_institucion' => array(),
      't_nombre' => array(),
      't_domicilio' => array(),
      't_localidad' => array(),
      't_ciudad' => array(),
      't_departamento' => array(),
      't_provincia' => array(),
      't_dependede' => array(),
      't_cargo' => array(),
      't_descripcion_tareas' => array(),
      'f_cursos_pol_sociales' => array(),
      'f_cursos_niniez' => array(),
      'f_tematicas_curso' => array(),
      'f_lugarcurso' => array(),
      'f_lugarcurso_otro' => array(),
      'aprobado' => array(),
      'ingresado' => array(),
      'created_at' => array(),
      'updated_at' => array(),
    );
  }

  public function getFieldsNew()
  {
    return array(
      'id' => array(),
      'p_apellido' => array(),
      'p_nombre' => array(),
      'p_sexo' => array(),
      'p_edad' => array(),
      'p_dni' => array(),
      'p_email' => array(),
      'p_provincia' => array(),
      'p_ciudad' => array(),
      'p_localidad' => array(),
      'p_titulo_obtenido' => array(),
      'p_acceso_internet' => array(),
      'p_realizado_curso' => array(),
      't_institucion' => array(),
      't_nombre' => array(),
      't_domicilio' => array(),
      't_localidad' => array(),
      't_ciudad' => array(),
      't_departamento' => array(),
      't_provincia' => array(),
      't_dependede' => array(),
      't_cargo' => array(),
      't_descripcion_tareas' => array(),
      'f_cursos_pol_sociales' => array(),
      'f_cursos_niniez' => array(),
      'f_tematicas_curso' => array(),
      'f_lugarcurso' => array(),
      'f_lugarcurso_otro' => array(),
      'aprobado' => array(),
      'ingresado' => array(),
      'created_at' => array(),
      'updated_at' => array(),
    );
  }


  /**
   * Gets the form class name.
   *
   * @return string The form class name
   */
  public function getFormClass()
  {
    return 'RegistracionForm';
  }

  public function hasFilterForm()
  {
    return false;
  }

  /**
   * Gets the filter form class name
   *
   * @return string The filter form class name associated with this generator
   */
  public function getFilterFormClass()
  {
    return 'RegistracionFormFilter';
  }

  public function getPagerClass()
  {
    return 'sfDoctrinePager';
  }

  public function getPagerMaxPerPage()
  {
    return 12;
  }

  public function getDefaultSort()
  {
    return array(null, null);
  }

  public function getTableMethod()
  {
    return '';
  }

  public function getTableCountMethod()
  {
    return '';
  }
}
