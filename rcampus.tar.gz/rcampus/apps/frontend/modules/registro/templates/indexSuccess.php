<h1>Registracions List</h1>

<table>
  <thead>
    <tr>
      <th>Id</th>
      <th>P apellido</th>
      <th>P nombre</th>
      <th>P sexo</th>
      <th>P edad</th>
      <th>P dni</th>
      <th>P email</th>
      <th>P provincia</th>
      <th>P ciudad</th>
      <th>P localidad</th>
      <th>P titulo obtenido</th>
      <th>P acceso internet</th>
      <th>P realizado curso</th>
      <th>T institucion</th>
      <th>T nombre</th>
      <th>T domicilio</th>
      <th>T localidad</th>
      <th>T ciudad</th>
      <th>T departamento</th>
      <th>T provincia</th>
      <th>T dependede</th>
      <th>T cargo</th>
      <th>T descripcion tareas</th>
      <th>F cursos pol sociales</th>
      <th>F cursos niniez</th>
      <th>F tematicas curso</th>
      <th>F lugarcurso</th>
      <th>F lugarcurso otro</th>
      <th>Created at</th>
      <th>Updated at</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach ($registracions as $registracion): ?>
    <tr>
      <td><a href="<?php echo url_for('registro/show?id='.$registracion->getId()) ?>"><?php echo $registracion->getId() ?></a></td>
      <td><?php echo $registracion->getPApellido() ?></td>
      <td><?php echo $registracion->getPNombre() ?></td>
      <td><?php echo $registracion->getPSexo() ?></td>
      <td><?php echo $registracion->getPEdad() ?></td>
      <td><?php echo $registracion->getPDni() ?></td>
      <td><?php echo $registracion->getPEmail() ?></td>
      <td><?php echo $registracion->getPProvincia() ?></td>
      <td><?php echo $registracion->getPCiudad() ?></td>
      <td><?php echo $registracion->getPLocalidad() ?></td>
      <td><?php echo $registracion->getPTituloObtenido() ?></td>
      <td><?php echo $registracion->getPAccesoInternet() ?></td>
      <td><?php echo $registracion->getPRealizadoCurso() ?></td>
      <td><?php echo $registracion->getTInstitucion() ?></td>
      <td><?php echo $registracion->getTNombre() ?></td>
      <td><?php echo $registracion->getTDomicilio() ?></td>
      <td><?php echo $registracion->getTLocalidad() ?></td>
      <td><?php echo $registracion->getTCiudad() ?></td>
      <td><?php echo $registracion->getTDepartamento() ?></td>
      <td><?php echo $registracion->getTProvincia() ?></td>
      <td><?php echo $registracion->getTDependede() ?></td>
      <td><?php echo $registracion->getTCargo() ?></td>
      <td><?php echo $registracion->getTDescripcionTareas() ?></td>
      <td><?php echo $registracion->getFCursosPolSociales() ?></td>
      <td><?php echo $registracion->getFCursosNiniez() ?></td>
      <td><?php echo $registracion->getFTematicasCurso() ?></td>
      <td><?php echo $registracion->getFLugarcurso() ?></td>
      <td><?php echo $registracion->getFLugarcursoOtro() ?></td>
      <td><?php echo $registracion->getCreatedAt() ?></td>
      <td><?php echo $registracion->getUpdatedAt() ?></td>
    </tr>
    <?php endforeach; ?>
  </tbody>
</table>

  <a href="<?php echo url_for('registro/new') ?>">New</a>
