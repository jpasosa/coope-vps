<?php use_stylesheets_for_form($form) ?>
<?php use_javascripts_for_form($form) ?>

<form action="<?php echo url_for('registro/'.($form->getObject()->isNew() ? 'create' : 'update').(!$form->getObject()->isNew() ? '?id='.$form->getObject()->getId() : '')) ?>" method="post" <?php $form->isMultipart() and print 'enctype="multipart/form-data" ' ?>>
<?php if (!$form->getObject()->isNew()): ?>
<input type="hidden" name="sf_method" value="put" />
<?php endif; ?>
  <table>
    <tfoot>
      <tr>
        <td colspan="2">
          &nbsp;<a href="<?php echo url_for('registro/index') ?>">Back to list</a>
          <?php if (!$form->getObject()->isNew()): ?>
            &nbsp;<?php echo link_to('Delete', 'registro/delete?id='.$form->getObject()->getId(), array('method' => 'delete', 'confirm' => 'Are you sure?')) ?>
          <?php endif; ?>
          <input type="submit" value="Save" />
        </td>
      </tr>
    </tfoot>
      <ul>
        <li>
          <?php echo $form['p_apellido']->renderLabel(); ?>
          <?php echo $form['p_apellido']->render(); ?>
          <?php echo $form['p_apellido']->renderError(); ?>
        </li>
        <li>
          <?php echo $form['p_nombre']->renderLabel(); ?>
          <?php echo $form['p_nombre']->render(); ?>
          <?php echo $form['p_nombre']->renderError(); ?>
        </li>
        <li>
          <?php echo $form['p_sexo']->renderLabel(); ?>
          <?php echo $form['p_sexo']->render(); ?>
          <?php echo $form['p_sexo']->renderError(); ?>
        </li>
        <li>
          <?php echo $form['p_edad']->renderLabel(); ?>
          <?php echo $form['p_edad']->render(); ?>
          <?php echo $form['p_edad']->renderError(); ?>
        </li>
        <li>
          <?php echo $form['p_dni']->renderLabel(); ?>
          <?php echo $form['p_dni']->render(); ?>
          <?php echo $form['p_dni']->renderError(); ?>
        </li>
        <li>
          <?php echo $form['p_email']->renderLabel(); ?>
          <?php echo $form['p_email']->render(); ?>
          <?php echo $form['p_email']->renderError(); ?>
        </li>
        <li>
          <?php echo $form['p_provincia']->renderLabel(); ?>
          <?php echo $form['p_provincia']->render(); ?>
          <?php echo $form['p_provincia']->renderError(); ?>
        </li>
        <li>
          <?php echo $form['p_ciudad']->renderLabel(); ?>
          <?php echo $form['p_ciudad']->render(); ?>
          <?php echo $form['p_ciudad']->renderError(); ?>
        </li>
        <li>
          <?php echo $form['p_localidad']->renderLabel(); ?>
          <?php echo $form['p_localidad']->render(); ?>
          <?php echo $form['p_localidad']->renderError(); ?>
        </li>
        <li>
          <?php echo $form['p_titulo_obtenido']->renderLabel(); ?>
          <?php echo $form['p_titulo_obtenido']->render(); ?>
          <?php echo $form['p_titulo_obtenido']->renderError(); ?>
        </li>
        <li>
          <?php echo $form['p_acceso_internet']->renderLabel(); ?>
          <?php echo $form['p_acceso_internet']->render(); ?>
          <?php echo $form['p_acceso_internet']->renderError(); ?>
        </li>
        <li>
          <?php echo $form['p_realizado_curso']->renderLabel(); ?>
          <?php echo $form['p_realizado_curso']->render(); ?>
          <?php echo $form['p_realizado_curso']->renderError(); ?>
        </li>
        <li>
          <?php echo $form['t_institucion']->renderLabel(); ?>
          <?php echo $form['t_institucion']->render(); ?>
          <?php echo $form['t_institucion']->renderError(); ?>
        </li>
        <li>
          <?php echo $form['t_nombre']->renderLabel(); ?>
          <?php echo $form['t_nombre']->render(); ?>
          <?php echo $form['t_nombre']->renderError(); ?>
        </li>
        <li>
          <?php echo $form['t_domicilio']->renderLabel(); ?>
          <?php echo $form['t_domicilio']->render(); ?>
          <?php echo $form['t_domicilio']->renderError(); ?>
        </li>
        <li>
          <?php echo $form['t_localidad']->renderLabel(); ?>
          <?php echo $form['t_localidad']->render(); ?>
          <?php echo $form['t_localidad']->renderError(); ?>
        </li>
        <li>
          <?php echo $form['t_ciudad']->renderLabel(); ?>
          <?php echo $form['t_ciudad']->render(); ?>
          <?php echo $form['t_ciudad']->renderError(); ?>
        </li>
        <li>
          <?php echo $form['t_departamento']->renderLabel(); ?>
          <?php echo $form['t_departamento']->render(); ?>
          <?php echo $form['t_departamento']->renderError(); ?>
        </li>
        <li>
          <?php echo $form['t_provincia']->renderLabel(); ?>
          <?php echo $form['t_provincia']->render(); ?>
          <?php echo $form['t_provincia']->renderError(); ?>
        </li>
        <li>
          <?php echo $form['t_dependede']->renderLabel(); ?>
          <?php echo $form['t_dependede']->render(); ?>
          <?php echo $form['t_dependede']->renderError(); ?>
        </li>
        <li>
          <?php echo $form['t_cargo']->renderLabel(); ?>
          <?php echo $form['t_cargo']->render(); ?>
          <?php echo $form['t_cargo']->renderError(); ?>
        </li>
        <li>
          <?php echo $form['t_descripcion_tareas']->renderLabel(); ?>
          <?php echo $form['t_descripcion_tareas']->render(); ?>
          <?php echo $form['t_descripcion_tareas']->renderError(); ?>
        </li>
        <li>
          <?php echo $form['f_cursos_pol_sociales']->renderLabel(); ?>
          <?php echo $form['f_cursos_pol_sociales']->render(); ?>
          <?php echo $form['f_cursos_pol_sociales']->renderError(); ?>
        </li>
        <li>
          <?php echo $form['f_cursos_niniez']->renderLabel(); ?>
          <?php echo $form['f_cursos_niniez']->render(); ?>
          <?php echo $form['f_cursos_niniez']->renderError(); ?>
        </li>
        <li>
          <?php echo $form['f_tematicas_curso']->renderLabel(); ?>
          <?php echo $form['f_tematicas_curso']->render(); ?>
          <?php echo $form['f_tematicas_curso']->renderError(); ?>
        </li>
        <li>
          <?php echo $form['f_lugarcurso']->renderLabel(null, array('class' => 'lugar_curso')); ?>
          <?php echo $form['f_lugarcurso']->render(); ?>
          <?php echo $form['f_lugarcurso']->renderError(); ?>
        </li>
        <li>
          <?php echo $form['f_lugarcurso_otro']->renderLabel(); ?>
          <?php echo $form['f_lugarcurso_otro']->render(); ?>
          <?php echo $form['f_lugarcurso_otro']->renderError(); ?>
        </li>
      </ul>

      <?php echo $form->renderHiddenFields(); ?>

      <?php // echo $form ?>


  </table>
</form>
