<table>
  <tbody>
    <tr>
      <th>Id:</th>
      <td><?php echo $registracion->getId() ?></td>
    </tr>
    <tr>
      <th>P apellido:</th>
      <td><?php echo $registracion->getPApellido() ?></td>
    </tr>
    <tr>
      <th>P nombre:</th>
      <td><?php echo $registracion->getPNombre() ?></td>
    </tr>
    <tr>
      <th>P sexo:</th>
      <td><?php echo $registracion->getPSexo() ?></td>
    </tr>
    <tr>
      <th>P edad:</th>
      <td><?php echo $registracion->getPEdad() ?></td>
    </tr>
    <tr>
      <th>P dni:</th>
      <td><?php echo $registracion->getPDni() ?></td>
    </tr>
    <tr>
      <th>P email:</th>
      <td><?php echo $registracion->getPEmail() ?></td>
    </tr>
    <tr>
      <th>P provincia:</th>
      <td><?php echo $registracion->getPProvincia() ?></td>
    </tr>
    <tr>
      <th>P ciudad:</th>
      <td><?php echo $registracion->getPCiudad() ?></td>
    </tr>
    <tr>
      <th>P localidad:</th>
      <td><?php echo $registracion->getPLocalidad() ?></td>
    </tr>
    <tr>
      <th>P titulo obtenido:</th>
      <td><?php echo $registracion->getPTituloObtenido() ?></td>
    </tr>
    <tr>
      <th>P acceso internet:</th>
      <td><?php echo $registracion->getPAccesoInternet() ?></td>
    </tr>
    <tr>
      <th>P realizado curso:</th>
      <td><?php echo $registracion->getPRealizadoCurso() ?></td>
    </tr>
    <tr>
      <th>T institucion:</th>
      <td><?php echo $registracion->getTInstitucion() ?></td>
    </tr>
    <tr>
      <th>T nombre:</th>
      <td><?php echo $registracion->getTNombre() ?></td>
    </tr>
    <tr>
      <th>T domicilio:</th>
      <td><?php echo $registracion->getTDomicilio() ?></td>
    </tr>
    <tr>
      <th>T localidad:</th>
      <td><?php echo $registracion->getTLocalidad() ?></td>
    </tr>
    <tr>
      <th>T ciudad:</th>
      <td><?php echo $registracion->getTCiudad() ?></td>
    </tr>
    <tr>
      <th>T departamento:</th>
      <td><?php echo $registracion->getTDepartamento() ?></td>
    </tr>
    <tr>
      <th>T provincia:</th>
      <td><?php echo $registracion->getTProvincia() ?></td>
    </tr>
    <tr>
      <th>T dependede:</th>
      <td><?php echo $registracion->getTDependede() ?></td>
    </tr>
    <tr>
      <th>T cargo:</th>
      <td><?php echo $registracion->getTCargo() ?></td>
    </tr>
    <tr>
      <th>T descripcion tareas:</th>
      <td><?php echo $registracion->getTDescripcionTareas() ?></td>
    </tr>
    <tr>
      <th>F cursos pol sociales:</th>
      <td><?php echo $registracion->getFCursosPolSociales() ?></td>
    </tr>
    <tr>
      <th>F cursos niniez:</th>
      <td><?php echo $registracion->getFCursosNiniez() ?></td>
    </tr>
    <tr>
      <th>F tematicas curso:</th>
      <td><?php echo $registracion->getFTematicasCurso() ?></td>
    </tr>
    <tr>
      <th>F lugarcurso:</th>
      <td><?php echo $registracion->getFLugarcurso() ?></td>
    </tr>
    <tr>
      <th>F lugarcurso otro:</th>
      <td><?php echo $registracion->getFLugarcursoOtro() ?></td>
    </tr>
    <tr>
      <th>Created at:</th>
      <td><?php echo $registracion->getCreatedAt() ?></td>
    </tr>
    <tr>
      <th>Updated at:</th>
      <td><?php echo $registracion->getUpdatedAt() ?></td>
    </tr>
  </tbody>
</table>

<hr />

<a href="<?php echo url_for('registro/edit?id='.$registracion->getId()) ?>">Edit</a>
&nbsp;
<a href="<?php echo url_for('registro/index') ?>">List</a>
