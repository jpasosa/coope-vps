<h1>Edit Registracion</h1>

<?php include_partial('form', array('form' => $form)) ?>
