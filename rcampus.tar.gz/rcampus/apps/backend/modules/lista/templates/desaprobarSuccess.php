<div class="aprobar">
  La DESAPROBACION de <?=$registro->getP_apellido(); ?> se ha realizado con éxito.
  <?=link_to('volver al listado','@lista'); ?>
</div>
