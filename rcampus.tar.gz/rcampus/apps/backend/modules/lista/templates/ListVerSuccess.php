<?php $id = $registro->getId(); ?>


<div class="ver-registros">
  <div class="cuerpo">
    <div class="personal">
      <div class="campo">
        <div class="nombre"> Apellido: </div>
        <div class="valor"> <?=$registro->getP_apellido(); ?> </div>
      </div>
      <div class="campo">
        <div class="nombre"> Nombre: </div>
        <div class="valor"> <?=$registro->getP_nombre(); ?> </div>
      </div>
      <div class="campo">
        <div class="nombre"> Sexo: </div>
        <div class="nombre"> <?=$registro->getP_sexo(); ?> </div>
      </div>
      <div class="campo">
        <div class="nombre"> Edad: </div>
        <div class="valor"> <?=$registro->getP_edad(); ?> </div>
      </div>
      <div class="campo">
        <div class="nombre"> Dni: </div>
        <div class="valor"> <?=$registro->getP_dni(); ?> </div>
      </div>
      <div class="campo">
        <div class="nombre"> Email: </div>
        <div class="valor"> <?=$registro->getP_email(); ?> </div>
      </div>
      <div class="campo">
        <div class="nombre"> Provincia: </div>
        <div class="valor"> <?=$registro->getP_provincia(); ?> </div>
      </div>
      <div class="campo">
        <div class="nombre"> Ciudad: </div>
        <div class="valor"> <?=$registro->getP_ciudad(); ?> </div>
      </div>
      <div class="campo">
        <div class="nombre"> Localidad: </div>
        <div class="valor"> <?=$registro->getP_localidad(); ?> </div>
      </div>
      <div class="campo">
        <div class="nombre"> Titulo Obtenido: </div>
        <div class="valor"> <?=$registro->getP_titulo_obtenido(); ?> </div>
      </div>
      <div class="campo">
        <div class="nombre"> Acceso Internet: </div>
        <div class="valor"> <?=$registro->getP_acceso_internet(); ?> </div>
      </div>
      <div class="campo">
        <div class="nombre">Realizado Curso: </div>
        <div class="valor"> <?=$registro->getP_realizado_curso(); ?> </div>
      </div>
    </div>
    <div class="work">
      <div class="campo">
        <div class="nombre"> Institucion: </div>
        <div class="valor"> <?=$registro->getT_institucion(); ?> </div>
      </div>
      <div class="campo">
        <div class="nombre"> Nombre: </div>
        <div class="valor"> <?=$registro->getT_nombre(); ?> </div>
      </div>
      <div class="campo">
        <div class="nombre"> Domicilio: </div>
        <div class="valor"> <?=$registro->getT_domicilio();  ?> </div>
      </div>
      <div class="campo">
        <div class="nombre"> Localidad: </div>
        <div class="valor"> <?=$registro->getT_localidad(); ?> </div>
      </div>
      <div class="campo">
        <div class="nombre"> Ciudad: </div>
        <div class="valor"> <?=$registro->getT_ciudad(); ?> </div>
      </div>
      <div class="campo">
        <div class="nombre"> Departamento: </div>
        <div class="valor"> <?=$registro->getT_departamento(); ?> </div>
      </div>
      <div class="campo">
        <div class="nombre"> Provincia: </div>
        <div class="valor"> <?=$registro->getT_provincia(); ?> </div>
      </div>
      <div class="campo">
        <div class="nombre"> Depende: </div>
        <div class="valor"> <?=$registro->getT_dependede(); ?> </div>
      </div>
      <div class="campo">
        <div class="nombre"> Cargo: </div>
        <div class="valor"> <?=$registro->getT_cargo(); ?> </div>
      </div>
      <div class="campo">
        <div class="nombre"> Descripción de Tareas: </div>
        <div class="valor"> <?=$registro->getT_descripcion_tareas(); ?> </div>
      </div>
    </div>
    <div class="formacion">
      <div class="campo">
        <div class="nombre"> Cursos sobre Políticas Sociales: </div>
        <div class="valor"> <?=$registro->getF_cursos_pol_sociales(); ?>  </div>
      </div>
      <div class="campo">
        <div class="nombre"> Cursos de Niñez: </div>
        <div class="valor"> <?=$registro->getF_cursos_niniez(); ?> </div>
      </div>
      <div class="campo">
        <div class="nombre"> Tematica del curso: </div>
        <div class="valor"> <?=$registro->getF_tematicas_curso(); ?> </div>
      </div>
      <div class="campo">
        <div class="nombre"> Lugar del Curso: </div>
        <div class="valor"> <?=$registro->getF_lugarcurso(); ?> </div>
      </div>
      <div class="campo">
        <div class="nombre"> Otro lugar del curso: </div>
        <div class="valor"> <?=$registro->getF_lugarcurso_otro(); ?> </div>
      </div>
    </div>



    <?=link_to('Anterior', 'lista/ListVer?id='.$id_anterior);?>
    <?=link_to('Siguiente', 'lista/ListVer?id='.$id_siguiente);?>
    <?=link_to('volver al listado','@lista'); ?>
    <?=link_to('APROBAR','lista/aprobar?id='.$id); ?>
    <?=link_to('DESAPROBAR','lista/desaprobar?id='.$id); ?>
    <!-- <?=link_to('Pasar aprobados a CSV','lista/RegistrantsToCsv?id='.$id); ?> -->
  </div>
</div>




