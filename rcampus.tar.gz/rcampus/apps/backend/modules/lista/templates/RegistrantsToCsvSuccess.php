


<div class="csv">
  Se ha generado un archivo .csv
</div>




<?=link_to('volver al listado','@lista'); ?>
