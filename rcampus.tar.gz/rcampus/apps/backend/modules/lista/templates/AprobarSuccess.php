<div class="ver-registros">
  <div class="titulo">
    <?php echo('Registro de '.$registro->getP_apellido()); ?>
  </div>
  <div class="cuerpo">
    <div class="campo">
      <div class="nombre"> Apellido: </div>
      <div class="valor"> <?=$registro->getP_apellido(); ?> </div>
    </div>
    <div class="campo">
      <div class="nombre"> Nombre: </div>
      <div class="valor"> <?=$registro->getP_nombre(); ?> </div>
    </div>
    <div class="campo">
      <div class="nombre"> Sexo: </div>
      <div class="nombre"> <?=$registro->getP_sexo(); ?> </div>
    </div>




<?=link_to('Anterior', 'lista/ListVer?id='.$id_anterior);?>
<?=link_to('Siguiente', 'lista/ListVer?id='.$id_siguiente);?>

  <?=link_to('volver al listado','@lista'); ?>      
  </div>

</div>




