este es el template del modulo VER


<?php foreach ($listas as $lista): ?>
  <tr>
    <td>
      <?php echo $lista->getId() ?>
      <?php echo $lista->getP_apellido() ?>
      <?php echo $lista->getP_nombre() ?>
      <?php echo $lista->getP_sexo() ?>        
    </td>
  </tr>
<?php endforeach; ?>


<?php echo print_r($reg); ?>

<div class="titulo"> <?=$coleccion_actual->titulo; ?> </div>
