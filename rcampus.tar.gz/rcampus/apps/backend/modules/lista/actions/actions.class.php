<?php

require_once dirname(__FILE__).'/../lib/listaGeneratorConfiguration.class.php';
require_once dirname(__FILE__).'/../lib/listaGeneratorHelper.class.php';

/**
 * lista actions.
 *
 * @package    rcampus
 * @subpackage lista
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class listaActions extends autoListaActions
  {
  public function executeListVer(sfWebRequest $request)
    {
    $id = $request->getParameter('id');
    $this->registro = Doctrine::getTable('Registracion')
      ->findOneBy('Id', $id);
    $registros = Doctrine::getTable('Registracion')
      ->findAll();
    $iterator = $registros->getIterator();
    while($registro_actual = $iterator->current()):
      if($registro_actual->id == $id):
        if($iterator->key() == 0): // ESTE ES EL CASO EN EL QUE EL REGISTRO QUE SE ESTA VIENDO ES EL PRIMERO
          $this->id_anterior = 0;
          $iterator->next();
          $registro_siguiente = $iterator->current();
          $this->id_siguiente = $registro_siguiente->id;
        elseif($iterator->key()+1 < $iterator->count()):
          $this->id_anterior = $registro_anterior->id;
          $iterator->next();
          $registro_siguiente = $iterator->current();
          $this->id_siguiente = $registro_siguiente->id;
        else: // ESTE ES EL CASO EN EL QUE EL REGISTRO QUE SE ESTA VIENDO ES EL ULTIMO
          $this->id_anterior = $registro_anterior->id;
          $this->id_siguiente = 0;
        endif;
        break;
      else:
        $registro_anterior = $iterator->current();
        $iterator->next();
      endif;
    endwhile;
    }

  public function executeAprobar(sfWebRequest $request)
    {
    $id = $request->getParameter('id');
    //$registro = Doctrine::getTable('Registracion') ->findOneBy('Id', $id);
    $this->registro = Doctrine::getTable('Registracion')
      ->findOneBy('Id', $id);
    $q = Doctrine_Query::create()
        ->update('Registracion')
        ->set('aprobado', '1')
        ->where('id ='.$id);
    $q->execute();
    }

  public function executeDesaprobar(sfWebRequest $request)
    {
    $id = $request->getParameter('id');
    //$registro = Doctrine::getTable('Registracion') ->findOneBy('Id', $id);
    $this->registro = Doctrine::getTable('Registracion')
      ->findOneBy('Id', $id);
    $q = Doctrine_Query::create()
        ->update('Registracion')
        ->set('aprobado', '0')
        ->where('id ='.$id);
    $q->execute();
    }


    public function executeRegistrantsToCsv(sfWebRequest $request)
      {
      $id = $request->getParameter('id');
      $w = Doctrine_Query::create()
          ->update('Registracion')
          ->set('ingresado', '1')
          ->where('aprobado = 1');
      $w->execute();

      // Hago coleccion con aprobados y guardo en $aprobados
      $q = Doctrine_Query::create()
        ->from('Registracion u')
        ->where('u.aprobado = ?', '1');
      $aprobados = $q->fetchArray();
      $cant_aprobados = count($aprobados);
      $a = 0;
      //print_r($aprobados);
      // foreach para armar bien el arreglo
      foreach($aprobados as $campo):
        if($a==0) {
          $listas[0]['user']= 'user';
          $listas[0]['pass'] = 'pass';
          $listas[0]['firstname'] = 'firstname';
          $listas[0]['lastname'] = 'lastname';
          $listas[0]['email'] = 'email';
          $listas[1]['user']= $campo['p_apellido'];
          $listas[1]['pass'] = $campo['p_dni'];
          $listas[1]['firstname'] = $campo['p_nombre'];
          $listas[1]['lastname'] = $campo['p_apellido'];
          $listas[1]['email'] = $campo['p_email'];
          $a = 2;
          }
        else {
          $listas[$a]['user']= $campo['p_apellido'];
          $listas[$a]['pass'] = $campo['p_dni'];
          $listas[$a]['firstname'] = $campo['p_nombre'];
          $listas[$a]['lastname'] = $campo['p_apellido'];
          $listas[$a]['email'] = $campo['p_email'];
          $a = $a + 1;
          }
      endforeach;

      //foreach para cargar el .csv con al arreglo ya armado
      $fp = fopen('uploads/file.csv', 'w');
      foreach ($listas as $fields):
        fputcsv($fp, $fields);
      endforeach;
      fclose($fp);
      }

public function executeListRegistrantsToCsv(sfWebRequest $request)
      {
      $id = $request->getParameter('id');
      $w = Doctrine_Query::create()
          ->update('Registracion')
          ->set('ingresado', '1')
          ->where('aprobado = 1');
      $w->execute();

      // Hago coleccion con aprobados y guardo en $aprobados
      $q = Doctrine_Query::create()
        ->from('Registracion u')
        ->where('u.aprobado = ?', '1');
      $aprobados = $q->fetchArray();
      $cant_aprobados = count($aprobados);
      $a = 0;
      //print_r($aprobados);
      // foreach para armar bien el arreglo
      foreach($aprobados as $campo):
        if($a==0) {
          $listas[0]['user']= 'user';
          $listas[0]['pass'] = 'pass';
          $listas[0]['firstname'] = 'firstname';
          $listas[0]['lastname'] = 'lastname';
          $listas[0]['email'] = 'email';
          $listas[1]['user']= $campo['p_apellido'];
          $listas[1]['pass'] = $campo['p_dni'];
          $listas[1]['firstname'] = $campo['p_nombre'];
          $listas[1]['lastname'] = $campo['p_apellido'];
          $listas[1]['email'] = $campo['p_email'];
          $a = 2;
          }
        else {
          $listas[$a]['user']= $campo['p_apellido'];
          $listas[$a]['pass'] = $campo['p_dni'];
          $listas[$a]['firstname'] = $campo['p_nombre'];
          $listas[$a]['lastname'] = $campo['p_apellido'];
          $listas[$a]['email'] = $campo['p_email'];
          $a = $a + 1;
          }
      endforeach;

      //foreach para cargar el .csv con al arreglo ya armado
      $fp = fopen('uploads/file.csv', 'w');
      foreach ($listas as $fields):
        fputcsv($fp, $fields);
      endforeach;
      fclose($fp);
      }

  public function executeBatchAprobar(sfWebRequest $request)
    {
    $ids = $request->getParameter('ids');
    foreach($ids as $id):
      $q = Doctrine_Query::create()
          ->update('Registracion')
          ->set('aprobado', '1')
          ->where('id ='.$id);
      $q->execute();
    endforeach;
    //TODO: Ver de mejorar el mensaje, si hay un error que diga que no pudo aprobarlo
    if(count($ids)>1):
      $this->getUser()->setFlash('notice', 'Los registros fueron aprobados con éxito');
    else:
      $this->getUser()->setFlash('notice', 'El registro fue aprobado con éxito');
    endif;
    
    }

  public function executeBatchDesaprobar(sfWebRequest $request)
    {
    $ids = $request->getParameter('ids');
    foreach($ids as $id):
      $q = Doctrine_Query::create()
          ->update('Registracion')
          ->set('aprobado', '0')
          ->where('id ='.$id);
      $q->execute();
    endforeach;
    //TODO: Ver de mejorar el mensaje, si hay un error que diga que no pudo aprobarlo
    if(count($ids)>1):
      $this->getUser()->setFlash('notice', 'Los registros fueron DESAPROBADOS con éxito');
    else:
      $this->getUser()->setFlash('notice', 'El registro fue DESAPROBADO con éxito');
    endif;






    }



}
















    


  


















